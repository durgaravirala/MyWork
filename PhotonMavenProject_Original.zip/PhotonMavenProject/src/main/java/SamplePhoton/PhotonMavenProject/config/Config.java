package SamplePhoton.PhotonMavenProject.config;

public class Config {
	
	public static String applicationURL = "<TBD>";
	public static String userName = "";
	public static String password = "";
	public static String chromeDriverPath = "D:\\Softwares\\chromedriver_win32\\chromedriver.exe";
}
