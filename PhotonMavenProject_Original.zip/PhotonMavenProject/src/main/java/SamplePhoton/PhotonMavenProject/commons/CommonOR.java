package SamplePhoton.PhotonMavenProject.commons;

public class CommonOR {
	
	public static String userNameXPath = "";
	public static String passWordXPath = "";
	public static String loginButtonXPath = "";
}
